With cyber threats increasing, protecting sensitive data is more important than ever. We are developing a website that consists a tool as a extension file module that protect databases using blockchain and high-level encryption to prevent unauthorized access, data breach,  data theft and other Vulnerabilities to data .
With the target audience as the beginner level web developers, to have their sites protected while developing and for prototype developers.
This Extension File module acts as a security shield, allowing only authorized users to access critical databases. Blockchain ensures transparency, immutability, and traceability, making data tamper-proof. At the same time, strong encryption protects data both when stored and transferred, preventing breaches.
Our project offers a safe and reliable way to secure sensitive information against cyber threats.

